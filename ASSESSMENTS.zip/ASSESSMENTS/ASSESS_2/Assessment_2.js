
console.log("Hello World!");

//Q12
const x = 11

if(x == '11'){
    console.log("first if statement")
}else if(x === '11'){
    console.log("second if statement")
}

/*
//Q13
function getcube()
{
var number =document.getElementById("number").value;
alert(number*number*number*number)
}
<form>
	Enter No:<input type="text" id="number" value="3" name="number"/></br>
  <input type="button" value="ok" onclick="getcube()"/>
</form>


//Q15
var pow=new Function("num1","num2","return Math.pow(num1,num2)");
document.writeIn(pow(2,3));
*/