﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OdeToFood.Core.Enums
{
    public enum CuisineType {
        None,
        Mexican,
        Italian,
        Indian
    }
}
