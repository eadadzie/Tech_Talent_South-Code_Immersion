﻿namespace CSharpDataTypes.Vehicles.Enums
{
    public enum CarType
    {
        SPORTY,
        FAMILY
    }
}
