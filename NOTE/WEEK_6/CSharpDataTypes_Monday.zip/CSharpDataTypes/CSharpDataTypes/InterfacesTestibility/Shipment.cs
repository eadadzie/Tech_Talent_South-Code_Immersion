﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpDataTypes.InterfacesTestibility
{
    class Shipment
    {
        public float Cost { get; set; }
        public DateTime ShippingDate { get; set; }
    }
}
