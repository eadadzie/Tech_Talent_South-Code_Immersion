﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Linq.Models
{
    public class Book
    {
        public string Title { get; set; }
        public float Price { get; set; }
    }
}
