﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpDataTypes.People
{
    interface IPerson {
        string Name { get; }
        int Age { get; }

    }
}
