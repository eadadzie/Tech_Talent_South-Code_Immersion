﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpDataTypes.Lambdas
{
    class Book
    {
        public string Title { get; set; }
        public int Price { get; set; }
    }
}
